document.querySelector('.chat[data-chat=person2]').classList.add('active-chat');
document.querySelector('.person[person-chat=person2]').classList.add('active');
//var msg='';
//var divid=1;
var friends = {
  list: document.querySelector('ul.people'),
  all: document.querySelectorAll('.left .person'),
  name: '' },

chat = {
  container: document.querySelector('.container .right'),//所有聊天放到container里边
  current: null,
  person: null,
  name: document.querySelector('.container .right .top .name') };//把聊天栏上面的属性付给"chat数组"中的name.


friends.all.forEach(function (f) {
  f.addEventListener('mousedown', function () {
	
    f.classList.contains('active') || setAciveChat(f);
  });
});

function setAciveChat(f) {
  friends.list.querySelector('.active').classList.remove('active');//移除之前选中的朋友的光标
  f.classList.add('active');//添加选中朋友光标
  chat.current = chat.container.querySelector('.active-chat');//把之前的聊天信息放到当前里边
  chat.person = f.getAttribute('person-chat');//把当前人放到数组
  chat.current.classList.remove('active-chat');//移除之前选中的朋友的聊天光标
  chat.container.querySelector('[data-chat="' + chat.person + '"]').classList.add('active-chat');//添加选中的朋友的聊天记录的光标
  friends.name = f.querySelector('.name').innerText;//把选中的朋友的名字放到 friends数组里。
  chat.name.innerHTML = friends.name;//把选中的朋友的名字放到右侧top处的名字上。
}
